
subject1_results = load_subject_data('AmirAli'); % Change 'Subject1' to the actual prefix for the first subject
subject2_results = load_subject_data('AmirReza'); % Change 'Subject2' to the actual prefix for the second subject

subject1_phases = segment_data(subject1_results);
subject2_phases = segment_data(subject2_results);

phase1_data = [subject1_phases{1}; subject2_phases{1}];
write_phase_data('phase1_data.txt', phase1_data);

phase2_data = [subject1_phases{2}; subject2_phases{2}];
write_phase_data('phase2_data.txt', phase2_data);

phase3_data = [subject1_phases{3}; subject2_phases{3}];
write_phase_data('phase3_data.txt', phase3_data);

function all_results = load_subject_data(subject_prefix)
    all_results = [];
    for i = 1:8
        block_name = sprintf('%s_block_%d', subject_prefix, i);
        data = load(block_name); % Load the .m file
        result_matrix = data.data.result; % Assuming the struct contains the 'result' field
        all_results = [all_results; result_matrix];
    end
end

function phase_results = segment_data(all_results)
    num_trials_per_block = 204;
    phase1 = all_results(1:num_trials_per_block*2, :);
    phase2 = all_results(num_trials_per_block*2+1:num_trials_per_block*6, :);
    phase3 = all_results(num_trials_per_block*6+1:end, :);
    
    phase_results = {phase1, phase2, phase3};
end
function write_phase_data(filename, phase_data)
    correctness = (phase_data(:, 3) == phase_data(:, 4));
    response_time = phase_data(:, 6);
    
    output_data = [correctness, response_time];
    
    fileID = fopen(filename, 'w');
    fprintf(fileID, '%d %.4f\n', output_data');
    fclose(fileID);
    
    fprintf('Data written to %s\n', filename);
end
