subject1_results = load_subject_data('AmirAli'); % Change 'Subject1' to the actual prefix for the first subject
subject2_results = load_subject_data('AmirReza'); % Change 'Subject2' to the actual prefix for the second subject

subject1_phases = segment_data(subject1_results);
subject2_phases = segment_data(subject2_results);



subject1_accuracy = zeros(3, 1);
subject1_avg_response_time = zeros(3, 1);
subject2_accuracy = zeros(3, 1);
subject2_avg_response_time = zeros(3, 1);

for phase = 1:3
    [subject1_accuracy(phase), subject1_avg_response_time(phase)] = calculate_metrics(subject1_phases{phase});
end

for phase = 1:3
    [subject2_accuracy(phase), subject2_avg_response_time(phase)] = calculate_metrics(subject2_phases{phase});
end

mean_accuracy = mean([subject1_accuracy, subject2_accuracy], 2);
sem_accuracy = std([subject1_accuracy, subject2_accuracy], 0, 2) / sqrt(2);

mean_response_time = mean([subject1_avg_response_time, subject2_avg_response_time], 2);
sem_response_time = std([subject1_avg_response_time, subject2_avg_response_time], 0, 2) / sqrt(2);

phases = {'Phase 1', 'Phase 2', 'Phase 3'}';
results_table = table(phases, mean_accuracy, sem_accuracy, mean_response_time, sem_response_time, ...
    'VariableNames', {'Phase', 'Mean_Accuracy', 'SEM_Accuracy', 'Mean_Response_Time', 'SEM_Response_Time'});

disp(results_table);

figure;
bar(1:3, mean_accuracy);
hold on;
errorbar(1:3, mean_accuracy, sem_accuracy, 'k', 'linestyle', 'none'); % Add error bars
set(gca, 'XTick', 1:3, 'XTickLabel', phases);
xlabel('Phase');
ylabel('Accuracy (%)');
title('Accuracy vs. Phase');
grid on;
hold off;

figure;
bar(1:3, mean_response_time);
hold on;
errorbar(1:3, mean_response_time, sem_response_time, 'k', 'linestyle', 'none'); % Add error bars
set(gca, 'XTick', 1:3, 'XTickLabel', phases);
xlabel('Phase');
ylabel('Response Time (s)');
title('Response Time vs. Phase');
grid on;
hold off;

function all_results = load_subject_data(subject_prefix)
    all_results = [];
    for i = 1:8
        block_name = sprintf('%s_block_%d', subject_prefix, i);
        data = load(block_name); % Load the .m file
        result_matrix = data.data.result; % Assuming the struct contains the 'result' field
        all_results = [all_results; result_matrix];
    end
end

function phase_results = segment_data(all_results)
    num_trials_per_block = 204;
    phase1 = all_results(1:num_trials_per_block*2, :);
    phase2 = all_results(num_trials_per_block*2+1:num_trials_per_block*6, :);
    phase3 = all_results(num_trials_per_block*6+1:end, :);
    
    phase_results = {phase1, phase2, phase3};
end
function [accuracy, avg_response_time] = calculate_metrics(phase_data)
    total_trials = size(phase_data, 1);
    correct_responses = sum(phase_data(:, 3) == phase_data(:, 4));
    accuracy = (correct_responses / total_trials) * 100;
    avg_response_time = mean(phase_data(:, 6));
end
