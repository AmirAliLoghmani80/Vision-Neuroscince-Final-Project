
%%

subject1_results = load_subject_data('AmirAli'); % Change 'Subject1' to the actual prefix for the first subject
subject2_results = load_subject_data('AmirReza'); % Change 'Subject2' to the actual prefix for the second subject

combined_results = {subject1_results, subject2_results};

unique_coherence_levels = unique([subject1_results(:, 2); subject2_results(:, 2)]);
unique_coherence_levels = unique_coherence_levels(2:end-1);

subject_accuracy = zeros(length(unique_coherence_levels), 2);
subject_reaction_time = zeros(length(unique_coherence_levels), 2);

for subj = 1:2
    all_results = combined_results{subj};
    for i = 1:length(unique_coherence_levels)
        coherence_level = unique_coherence_levels(i);
        
        specific_coherence_rows = all_results(all_results(:, 2) == coherence_level, :);
        
        correct_responses = sum(specific_coherence_rows(:, 3) == specific_coherence_rows(:, 4));
        
        total_trials = size(specific_coherence_rows, 1);
        
        accuracy = (correct_responses / total_trials) * 100;
        
        average_reaction_time = mean(specific_coherence_rows(:, 6));
        
        subject_accuracy(i, subj) = accuracy;
        subject_reaction_time(i, subj) = average_reaction_time;
    end
end

mean_accuracy = mean(subject_accuracy, 2);
sem_accuracy = std(subject_accuracy, 0, 2) / sqrt(2);
mean_reaction_time = mean(subject_reaction_time, 2);
sem_reaction_time = std(subject_reaction_time, 0, 2) / sqrt(2);

results_table = table(unique_coherence_levels, mean_accuracy, sem_accuracy, mean_reaction_time, sem_reaction_time, ...
    'VariableNames', {'Coherence_Level', 'Mean_Accuracy', 'SEM_Accuracy', 'Mean_Reaction_Time', 'SEM_Reaction_Time'});

disp(results_table);

figure;
errorbar(results_table.Coherence_Level, results_table.Mean_Accuracy, results_table.SEM_Accuracy, 'o-');
xlabel('Coherence Level');
ylabel('Accuracy (%)');
title('Accuracy vs. Coherence Level');
grid on;

figure;
errorbar(results_table.Coherence_Level, results_table.Mean_Reaction_Time, results_table.SEM_Reaction_Time, 'o-');
xlabel('Coherence Level');
ylabel('Reaction Time (s)');
title('Reaction Time vs. Coherence Level');
grid on;


xData = results_table.Coherence_Level;
yData = results_table.Mean_Accuracy / 100; % Normalize accuracy to range [0, 1]

weibull = fittype('1 - 0.5 * exp(- (x / lambda) ^ kappa)', 'independent', 'x', ...
    'coefficients', {'lambda', 'kappa'});

opts = fitoptions(weibull);
opts.StartPoint = [1, 1]; % Initial guesses for [lambda, kappa]
opts.Lower = [0, 0]; % Lower bounds for [lambda, kappa]
opts.Upper = [Inf, Inf]; % Upper bounds for [lambda, kappa]

[weibullFit, gof] = fit(xData, yData, weibull, opts);

disp(weibullFit);
disp(gof);

xFit = linspace(min(xData), max(xData), 100);
yFit = weibullFit(xFit);

figure;
errorbar(results_table.Coherence_Level, results_table.Mean_Accuracy, results_table.SEM_Accuracy, 'o');
hold on;

plot(xFit, yFit * 100, '-r'); % Multiply by 100 to convert back to percentage
xlabel('Coherence Level');
ylabel('Accuracy (%)');
title('Accuracy vs. Coherence Level with Weibull Fit');
legend('Data', 'Weibull Fit', 'Location', 'southeast');
grid on;
hold off;

function all_results = load_subject_data(subject_prefix)
    all_results = [];
    for i = 1:8
        block_name = sprintf('%s_block_%d', subject_prefix, i);
        data = load(block_name); % Load the .m file
        result_matrix = data.data.result; % Assuming the struct contains the 'result' field
        all_results = [all_results; result_matrix];
    end
end

