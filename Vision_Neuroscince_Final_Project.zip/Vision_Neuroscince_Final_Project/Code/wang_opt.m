% function wang_opt()
%     % Load experimental data for Phase 1
%     data_phase1 = load('phase1_data.txt');
% 
%     % Calculate average accuracy for experimental data
%     avg_acc_phase1 = mean(data_phase1(:,1));
% 
%     % Set initial parameter values and bounds for BADS
%     params_init = [0.5, 0.3255, 30];
%     lb = [0.1, 0.1, 10]; % Lower bounds
%     ub = [1, 1, 50]; % Upper bounds
% 
%     % Optimize parameters using BADS
%     addpath('C:\path\to\bads'); % Adjust this path to where you installed BADS
%     savepath;
%     options = bads('defaults');
%     options.MaxIter = 5; 
%     [opt_params, opt_cost] = bads(@cost_function, params_init, lb, ub, [], [], [], options);
% 
%     % Display optimized parameters and cost
%     fprintf('Optimized Parameters:\n');
%     fprintf('thr: %.4f\n', opt_params(1));
%     fprintf('I0: %.4f\n', opt_params(2));
%     fprintf('u0: %.4f\n', opt_params(3));
%     fprintf('Optimized Cost: %.4f\n', opt_cost);
% 
%     % Plot histograms for experimental and optimized simulated data
%     sim_data = WANG_E(opt_params(1), opt_params(2), opt_params(3));
%     plot_histogram_exp(data_phase1, 'Phase 1');
%     plot_histogram_stim(sim_data, 'Optimized Simulated Data');
% 
%     % Nested function to run the WANG model and collect data
%     function [C1] = WANG_E(thr, I0, u0)
%         nDT = 0.5;
%         coh = 1 * [0 3.2 6.4 12.8 25.6 51.2];
%         ModelRunNo = 5000;
% 
%         C1 = zeros(ModelRunNo, 6); % Pre-allocate matrix for performance
% 
%         for j0 = 1:ModelRunNo
%             r0 = (size(coh, 2) * 10 - 1e-4) * rand();
%             nn = 1 + floor(r0 / 10);
% 
%             X = WANG([thr, coh(nn), I0, u0]);
% 
%             C1(j0, 2) = nn; % coh
%             C1(j0, 3) = X(3); % choice
%             C1(j0, 5) = X(1) + nDT; % response time
%             C1(j0, 6) = X(3); % accuracy
%         end
%     end
% 
%     % Function to calculate average accuracy
%     function avg_acc = calculate_accuracy(data)
%         avg_acc = mean(data(:, 6));
%     end
% 
%     % Function to calculate histogram difference
%     function hist_diff = calculate_histogram_difference(exp_data, sim_data)
%         % Define bin edges
%         bin_edges = 0:0.1:2; % Adjust bin edges as necessary
% 
%         % Calculate histograms
%         exp_hist = histcounts(exp_data(:, 2), bin_edges, 'Normalization', 'probability');
%         sim_hist = histcounts(sim_data(:, 5), bin_edges, 'Normalization', 'probability');
% 
%         % Calculate sum of absolute differences
%         hist_diff = sum(abs(exp_hist - sim_hist));
%     end
% 
%     % Define the cost function for optimization using BADS
%     function cost = cost_function(params)
%         % Set model parameters
%         thr = params(1);
%         I0 = params(2);
%         u0 = params(3);
% 
%         % Run the WANG model with current parameters
%         sim_data = WANG_E(thr, I0, u0);
% 
%         % Calculate average accuracy for simulated data
%         avg_acc_sim = calculate_accuracy(sim_data);
% 
%         % Calculate histogram difference
%         hist_diff = calculate_histogram_difference(data_phase1, sim_data);
% 
%         % Calculate the cost as a weighted sum of accuracy difference and histogram difference
%         weight_accuracy = 1;
%         weight_histogram = 1;
%         cost = weight_accuracy * abs(avg_acc_sim - avg_acc_phase1) + weight_histogram * hist_diff;
%     end
% 
%     % Function to plot histogram of response times
%     function plot_histogram_exp(data, phase)
%         figure;
%         histogram(data(:, 2), 'BinWidth', 0.1); % Adjust 'BinWidth' as necessary
%         xlabel('Response Time (s)');
%         ylabel('Frequency');
%         title(['Histogram of Response Times for ', phase]);
%         grid on;
%     end
%     function plot_histogram_stim(data, phase)
%         figure;
%         histogram(data(:, 5), 'BinWidth', 0.1); % Adjust 'BinWidth' as necessary
%         xlabel('Response Time (s)');
%         ylabel('Frequency');
%         title(['Histogram of Response Times for ', phase]);
%         grid on;
%     end
% end
% 
function wang_opt()
    % Load experimental data for Phase 1
    data_phase3 = load('phase3_data.txt');

    % Calculate average accuracy for experimental data
    avg_acc_phase3 = mean(data_phase3(:,1));

    % Set initial parameter values for fminsearch
    params_init = [0.5, 0.3255, 30];

    % Define options for fminsearch
    options = optimset('Display', 'iter', 'MaxIter', 50);

    % Optimize parameters using fminsearch
    [opt_params, opt_cost] = fminsearch(@cost_function, params_init, options);
    sim_data = WANG_E(opt_params(1), opt_params(2), opt_params(3));

    avg_acc_sim = calculate_accuracy(sim_data);
    avg_rt_sim = mean(sim_data(:, 5));

    % Display optimized parameters, cost, and averages
    fprintf('Optimized Parameters:\n');
    fprintf('thr: %.4f\n', opt_params(1));
    fprintf('I0: %.4f\n', opt_params(2));
    fprintf('u0: %.4f\n', opt_params(3));
    fprintf('Optimized Cost: %.4f\n', opt_cost);
%     fprintf('Number of iterations: %d\n', output.iterations);
    fprintf('Average Accuracy for Experimental Data: %.4f\n', avg_acc_phase3);
    fprintf('Average Accuracy for Simulated Data: %.4f\n', avg_acc_sim);
%     fprintf('Average Response Time for Experimental Data: %.4f\n', avg_rt_phase1);
%     fprintf('Average Response Time for Simulated Data: %.4f\n', avg_rt_sim);

    % Plot histograms for experimental and optimized simulated data
    plot_histogram(data_phase3, 'Phase 3');
    plot_histogram_sim(sim_data, 'Optimized Simulated Data');

    % Nested function to run the WANG model and collect data
    function [C1] = WANG_E(thr, I0, u0)
        nDT = 0.5;
        coh = 1 * [0 3.2 6.4 12.8 25.6 51.2];
        ModelRunNo = 5000;

        C1 = zeros(ModelRunNo, 6); % Pre-allocate matrix for performance

        for j0 = 1:ModelRunNo
            r0 = (size(coh, 2) * 10 - 1e-4) * rand();
            nn = 1 + floor(r0 / 10);

            X = WANG([thr, coh(nn), I0, u0]);

            C1(j0, 2) = nn; % coh
            C1(j0, 3) = X(3); % choice
            C1(j0, 5) = X(1) + nDT; % response time
            C1(j0, 6) = X(3); % accuracy
        end
    end

    % Function to calculate average accuracy
    function avg_acc = calculate_accuracy(data)
        avg_acc = mean(data(:, 6));
    end

    % Function to calculate histogram difference
    function hist_diff = calculate_histogram_difference(exp_data, sim_data)
        % Define bin edges
        bin_edges = 0:0.1:2; % Adjust bin edges as necessary

        % Calculate histograms
        exp_hist = histcounts(exp_data(:, 2), bin_edges, 'Normalization', 'probability');
        sim_hist = histcounts(sim_data(:, 5), bin_edges, 'Normalization', 'probability');

        % Calculate sum of absolute differences
        hist_diff = sum(abs(exp_hist - sim_hist));
    end

    % Define the cost function for optimization using fminsearch
    function cost = cost_function(params)
        % Set model parameters
        thr = params(1);
        I0 = params(2);
        u0 = params(3);

        % Run the WANG model with current parameters
        sim_data = WANG_E(thr, I0, u0);

        % Calculate average accuracy for simulated data
        avg_acc_sim = calculate_accuracy(sim_data);

        % Calculate histogram difference
        hist_diff = calculate_histogram_difference(data_phase3, sim_data);

        % Calculate the cost as a weighted sum of accuracy difference and histogram difference
        weight_accuracy = 1;
        weight_histogram = 1;
        cost = weight_accuracy * abs(avg_acc_sim - avg_acc_phase3) + weight_histogram * hist_diff;
    end

    % Function to plot histogram of response times
    function plot_histogram(data, phase)
        figure;
        histogram(data(:, 2), 'BinWidth', 0.1); % Adjust 'BinWidth' as necessary
        xlabel('Response Time (s)');
        ylabel('Frequency');
        title(['Histogram of Response Times for ', phase]);
        grid on;
    end
    function plot_histogram_sim(data, phase)
        figure;
        histogram(data(:, 5), 'BinWidth', 0.02); % Adjust 'BinWidth' as necessary
        xlabel('Response Time (s)');
        ylabel('Frequency');
        title(['Histogram of Response Times for ', phase]);
        grid on;
    end
end

% function wang_opt()
%     % Load experimental data for Phase 1
%     data_phase1 = load('phase1_data.txt');
% 
%     % Calculate average accuracy and average response time for experimental data
%     avg_acc_phase1 = mean(data_phase1(:,1));
%     avg_rt_phase1 = mean(data_phase1(:, 2));
% 
%     % Set initial parameter values for fminsearch
%     params_init = [0.5, 0.3255, 30];
% 
%     % Define options for fminsearch
%     options = optimset('Display', 'iter', 'MaxIter', 100, 'MaxFunEvals', 600, 'OutputFcn', @outfun);
% 
%     % Initialize output function variables
%     iter_count = 0;
% 
%     % Optimize parameters using fminsearch
%     [opt_params, opt_cost, exitflag, output] = fminsearch(@cost_function, params_init, options);
% 
%     % Run the WANG model with optimized parameters
%     sim_data = WANG_E(opt_params(1), opt_params(2), opt_params(3));
% 
%     % Calculate average accuracy and average response time for simulated data
%     avg_acc_sim = calculate_accuracy(sim_data);
%     avg_rt_sim = mean(sim_data(:, 5));
% 
%     % Display optimized parameters, cost, and averages
%     fprintf('Optimized Parameters:\n');
%     fprintf('thr: %.4f\n', opt_params(1));
%     fprintf('I0: %.4f\n', opt_params(2));
%     fprintf('u0: %.4f\n', opt_params(3));
%     fprintf('Optimized Cost: %.4f\n', opt_cost);
%     fprintf('Number of iterations: %d\n', output.iterations);
%     fprintf('Average Accuracy for Experimental Data: %.4f\n', avg_acc_phase1);
%     fprintf('Average Accuracy for Simulated Data: %.4f\n', avg_acc_sim);
%     fprintf('Average Response Time for Experimental Data: %.4f\n', avg_rt_phase1);
%     fprintf('Average Response Time for Simulated Data: %.4f\n', avg_rt_sim);
% 
%     % Plot histograms for experimental and optimized simulated data
%     plot_histogram(data_phase1, 'Phase 1', 20); % Increase number of bins
%     plot_histogram_sim(sim_data, 'Optimized Simulated Data', 50); % Increase number of bins for simulated data
% 
%     % Nested function to run the WANG model and collect data
%     function [C1] = WANG_E(thr, I0, u0)
%         nDT = 0.5;
%         coh = 1 * [0 3.2 6.4 12.8 25.6 51.2];
%         ModelRunNo = 5000;
% 
%         C1 = zeros(ModelRunNo, 6); % Pre-allocate matrix for performance
% 
%         for j0 = 1:ModelRunNo
%             r0 = (size(coh, 2) * 10 - 1e-4) * rand();
%             nn = 1 + floor(r0 / 10);
% 
%             X = WANG([thr, coh(nn), I0, u0]);
% 
%             C1(j0, 2) = nn; % coh
%             C1(j0, 3) = X(3); % choice
%             C1(j0, 5) = X(1) + nDT; % response time
%             C1(j0, 6) = X(3); % accuracy
%         end
%     end
% 
%     % Function to calculate average accuracy
%     function avg_acc = calculate_accuracy(data)
%         avg_acc = mean(data(:, 6));
%     end
% 
%     % Function to calculate histogram difference
%     function hist_diff = calculate_histogram_difference(exp_data, sim_data)
%         % Define bin edges
%         bin_edges = 0:0.1:2; % Adjust bin edges as necessary
% 
%         % Calculate histograms
%         exp_hist = histcounts(exp_data(:, 1), bin_edges, 'Normalization', 'probability');
%         sim_hist = histcounts(sim_data(:, 5), bin_edges, 'Normalization', 'probability');
% 
%         % Calculate sum of absolute differences
%         hist_diff = sum(abs(exp_hist - sim_hist));
%     end
% 
%     % Define the cost function for optimization using fminsearch
%     function cost = cost_function(params)
%         % Set model parameters
%         thr = params(1);
%         I0 = params(2);
%         u0 = params(3);
% 
%         % Run the WANG model with current parameters
%         sim_data = WANG_E(thr, I0, u0);
% 
%         % Calculate average accuracy for simulated data
%         avg_acc_sim = calculate_accuracy(sim_data);
% 
%         % Calculate histogram difference
%         hist_diff = calculate_histogram_difference(data_phase1, sim_data);
% 
%         % Calculate the cost as a weighted sum of accuracy difference and histogram difference
%         weight_accuracy = 1;
%         weight_histogram = 1;
%         cost = weight_accuracy * abs(avg_acc_sim - avg_acc_phase1) + weight_histogram * hist_diff;
%     end
% 
%     % Output function to keep track of iterations
%     function stop = outfun(~,~,state)
%         stop = false;
%         if isequal(state,'iter')
%             iter_count = iter_count + 1;
%         end
%     end
% 
%     % Function to plot histogram of response times
%     function plot_histogram(data, phase, num_bins)
%         figure;
%         histogram(data(:, 2), num_bins, 'BinWidth', 0.1); % Adjust 'BinWidth' as necessary
%         xlabel('Response Time (s)');
%         ylabel('Frequency');
%         title(['Histogram of Response Times for ', phase]);
%         grid on;
%     end
%     function plot_histogram_sim(data, phase, num_bins)
%         figure;
%         histogram(data(:, 5), num_bins, 'BinWidth', 0.1); % Adjust 'BinWidth' as necessary
%         xlabel('Response Time (s)');
%         ylabel('Frequency');
%         title(['Histogram of Response Times for ', phase]);
%         grid on;
%     end
% end
