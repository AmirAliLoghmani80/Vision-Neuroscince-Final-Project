phases = {'Phase 1', 'Phase 2', 'Phase 3'};
drift_rates = [0.7069, 0.8481, 0.9236];
decision_boundaries = [0.7423, 0.7423, 0.6697];
non_decision_times = [0.4325, 0.4284, 0.4354];

figure;
plot(1:3, drift_rates, '-o', 'MarkerSize', 8, 'LineWidth', 2);
set(gca, 'XTick', 1:3, 'XTickLabel', phases);
xlabel('Phase');
ylabel('Drift Rate');
title('Drift Rate for Different Phases');
grid on;
for i = 1:length(drift_rates)
    text(i, drift_rates(i), num2str(drift_rates(i), '%.4f'), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end

figure;
plot(1:3, decision_boundaries, '-o', 'MarkerSize', 8, 'LineWidth', 2);
set(gca, 'XTick', 1:3, 'XTickLabel', phases);
xlabel('Phase');
ylabel('Decision Boundary');
title('Decision Boundary for Different Phases');
grid on;
for i = 1:length(decision_boundaries)
    text(i, decision_boundaries(i), num2str(decision_boundaries(i), '%.4f'), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end

figure;
plot(1:3, non_decision_times, '-o', 'MarkerSize', 8, 'LineWidth', 2);
set(gca, 'XTick', 1:3, 'XTickLabel', phases);
xlabel('Phase');
ylabel('Non-Decision Time (s)');
title('Non-Decision Time for Different Phases');
grid on;
for i = 1:length(non_decision_times)
    text(i, non_decision_times(i), num2str(non_decision_times(i), '%.4f'), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end
